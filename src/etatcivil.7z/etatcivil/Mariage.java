/*
 * Cours de remise a niveau Java.
 * Université de Franche-Comté.
 */
package etatcivil;

import java.util.*;
import java.io.*;

public class Mariage  implements Serializable  {

    public final static int POLYGNIE = 1;
    public final static boolean MARIAGE_HOMOSEXUEL = true;
    public final static int AGE_LEGAL_MARIAGE=16;
    public final static int CONSANGUNITE =4;
    Personne epoux1;
    Personne epoux2;
    private Calendar dateMariage;
    private String lieu;
    private Calendar dateDivorce;

    public Mariage(Personne epoux1, Personne epoux2, Calendar dateMariage, String lieu) throws LegalException {
        //on teste si ils ne sont pas deja mariés
        if(epoux1.nbMariageActifs(dateMariage)>=POLYGNIE)
            throw new LegalException(epoux1.getPrenom()+" est deja marié");
        if(epoux2.nbMariageActifs(dateMariage)>=POLYGNIE)
            throw new LegalException(epoux2.getPrenom()+" est deja marié");
        //on test la consagunite des epoux
        int niveauCousin  = epoux1.estCousin(epoux2);
        if(niveauCousin>=0 && niveauCousin<=CONSANGUNITE)
        {throw new LegalException("Maraige consanguin interdit");}
        if (!MARIAGE_HOMOSEXUEL==false &&
                ((epoux1 instanceof Homme && epoux2 instanceof Homme)
                || (epoux1 instanceof Femme && epoux2 instanceof Femme)
                )) {
            throw new LegalException("Mariage homosexuel interdit");
        }
        
        this.epoux1 = epoux1;
        this.epoux2 = epoux2;
        this.dateMariage = dateMariage;
        this.lieu = lieu;
       
    }
   
    public static int getPOLYGNIE() {
        return POLYGNIE;
    }

    public static boolean isMARIAGE_HOMOSEXUEL() {
        return MARIAGE_HOMOSEXUEL;
    }

    public Personne getEpoux1() {
        return epoux1;
    }

    public Personne getEpoux2() {
        return epoux2;
    }

    public Calendar getDateMariage() {
        return dateMariage;
    }

    public String getLieu() {
        return lieu;
    }

    public Calendar getDateDivorce() {
        return dateDivorce;
    }
    public void divorce(Calendar dateDivorce){
    if(dateDivorce.before(dateMariage))
        throw new LegalException("un divorce ne puet etre prononce avant le mariage");
 //   if(epoux1.getDeces()!=null && epoux1.getDeces())
    }

}
 


