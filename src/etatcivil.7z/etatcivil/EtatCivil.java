/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package etatcivil;

import java.io.File;
import java.util.*;

public class EtatCivil {

    public static void main(String[] args) {

        Homme adam;
        Femme eve;
        Homme abel;
        Homme cain;
        Femme awan;
        Homme henoch;
        Femme segen;

        try {
            adam = new Homme("Dupont", "Adam", new GregorianCalendar(-3000, 1, 1));

            eve = new Femme("Durand", "Eve", new GregorianCalendar(-2999, 1, 1));
            adam.decede(new  GregorianCalendar(-2981, 1, 1));
           
            abel = new Homme(adam, eve, "Abel", new GregorianCalendar(-2972, 8, 10));
            cain = new Homme(adam, eve, "Cain", new GregorianCalendar(-2975, 8, 10));
            awan = new Femme("Lambert", "Awan", new GregorianCalendar(-2974, 9, 30));
            segen  = new Femme("tek", "yoni", new GregorianCalendar(-2974, 9, 30));
            henoch = new Homme(cain, awan, "Hénoch", new GregorianCalendar(-2964, 1, 10));
            Mariage m = new Mariage(cain,segen,new GregorianCalendar(-2955, 1, 1),"paradis");
            //Mariage m1 = new Mariage(cain,henoch,new GregorianCalendar(-2990, 1, 1),"paradis");
            
            henoch.arbreGenealogique(0);
            int t = abel.estCousin(segen);
           //System.out.println(t);
            henoch.estFertile(new GregorianCalendar(-2900,8,10));
            abel.decede(new GregorianCalendar(2000,8,1));
            int n= adam.estAncetre(cain);
              // System.out.println(n);
             //int l = cain.nbMariageActifs(new GregorianCalendar(-2972,8,10));
               //System.out.println(l);
        } catch (Exception e) {
            System.out.println(e);
        }
       
        //File eri =new File(eri);
        Personne.sauvegardePopulation("bible.dat");
       // Personne.relecturepopulation("bible.dat");
        // System.out.println(Personne.population);
    }
  
}
